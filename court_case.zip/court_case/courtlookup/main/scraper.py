import time

def fetch_case_details(case_type, case_number, year):
    # Placeholder for real scraping logic
    # In real life you'd scrape using requests + BeautifulSoup or Selenium

    time.sleep(1)  # simulate delay

    return {
        "parties": "A vs B",
        "filing_date": "2023-03-15",
        "hearing_date": "2025-08-07",
        "latest_pdf": "https://example.com/judgment.pdf"
    }
