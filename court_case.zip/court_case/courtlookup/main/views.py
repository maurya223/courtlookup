from django.shortcuts import render
from .scraper import fetch_case_details

def home(request):
    result = None
    if request.method == "POST":
        case_type = request.POST['case_type']
        case_number = request.POST['case_number']
        year = request.POST['year']

        result = fetch_case_details(case_type, case_number, year)

    return render(request, 'main/home.html', {'result': result})
